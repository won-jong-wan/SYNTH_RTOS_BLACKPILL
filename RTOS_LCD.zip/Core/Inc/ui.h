/*
 * ui.h
 *
 *  Created on: Jan 14, 2026
 *      Author: 환중
 */

#ifndef INC_UI_H_
#define INC_UI_H_

#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* ===== 화면 상태 정의 ===== */
typedef enum {
    LCD_STATE_INIT = 0,
	LCD_STATE_MAIN_DASH,
	LCD_STATE_ADSR_VIEW
} LcdState_t;

/* ===== 전역 변수 (외부 접근용) ===== */
extern TaskHandle_t lcdTaskHandle;
extern QueueHandle_t lcdQueueHandle;
extern LcdState_t currentLcdState;

extern uint8_t adsr_samples[1024];
extern uint8_t filtered_samples[1024];

extern LcdState_t currentLcdState;
extern uint8_t selected_adsr_idx;

/* ===== 초기화 함수 ===== */
void UI_Init(void);

#endif /* INC_UI_H_ */
